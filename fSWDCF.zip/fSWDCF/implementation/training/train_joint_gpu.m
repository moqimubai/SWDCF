function [h, projection_matrix, res_norms] = train_joint_gpu(h, projection_matrix, init_samplef, yf, reg_filter, sample_energy, reg_energy, proj_energy, params, init_CG_opts, pad_sz, pad)

Xfyf = cellfun(@(Xf, yf) bsxfun(@times, conj(Xf), yf),init_samplef, yf, 'uniformoutput', false);
Xy = cellfun(@(X,pad_sz,pad) hf2h(X,pad_sz, pad), Xfyf, pad_sz,pad, 'uniformoutput', false);
Xy_H = cellfun(@(X) reshape(X, [], size(X,3))',Xy, 'uniformoutput', false);
% Construct stuff for the proj matrix part
% init_samplef = cellfun(@(x) permute(x, [4 3 1 2]), init_samplef, 'uniformoutput', false);
init_samplef_H = cellfun(@(X) reshape(X, [], size(X,3))', init_samplef, 'uniformoutput', false);

% Construct preconditioner
diag_M = cell(size(h));
diag_M(1,1,:) = cellfun(@(m, reg_energy) (1-params.precond_reg_param) * bsxfun(@plus, params.precond_data_param * m, (1-params.precond_data_param) * mean(m,3)) + params.precond_reg_param*params.filter_reg, sample_energy, 'uniformoutput',false);
diag_M(2,1,:) = cellfun(@(m) params.precond_proj_param * (m + params.projection_reg), proj_energy, 'uniformoutput',false);
% Allocate
rhs_samplef = cell(size(h));
res_norms = [];

for iter = 1:params.init_GN_iter
    % Project sample with new matrix
    init_samplef_proj = project_sample(init_samplef, projection_matrix);
    init_hf = cellfun(@(X,pad_sz,pad) h2hf(X,pad_sz, pad), h(1,1,:), pad_sz,pad, 'uniformoutput', false);
    % Construct the right hand side vector for the filter part
    rhs_samplef(1,1,:) = cellfun(@(xf, yf) bsxfun(@times, conj(xf), yf), init_samplef_proj, yf, 'uniformoutput', false);
    rhs_samplef(1,1,:) = cellfun(@(X,pad_sz,pad) hf2h(X,pad_sz,pad), rhs_samplef(1,1,:), pad_sz,pad, 'uniformoutput', false);
   
    init_h_H = cellfun(@(f) reshape(f, [], size(f,3)),h(1,1,:), 'uniformoutput', false);
    rhs_samplef(2,1,:) = cellfun(@(P, XyH, hH) (real(XyH * hH) - params.projection_reg * P), ...
        projection_matrix, Xy_H, init_h_H, 'uniformoutput', false);
    
    % Initialize the projection matrix increment to zero
    h(2,1,:) = cellfun(@(P) zeros(size(P), 'like', params.data_type), projection_matrix, 'uniformoutput', false);
    
    % do conjugate gradient

    [h, res_norms_temp] = pcg_ccot(...
        @(x) lhs_operation_joint_gpu(x, init_samplef_proj, reg_filter, init_samplef, init_samplef_H, init_hf, init_h_H,params.projection_reg, params.filter_reg, pad_sz, pad),...
        rhs_samplef, init_CG_opts, ...
        @(x) diag_precond(x, diag_M), ...
        [], @inner_product_joint, h);
    
    % Add to the projection matrix
    projection_matrix = cellfun(@plus, projection_matrix, h(2,1,:), 'uniformoutput', false);
    
    res_norms = [res_norms; res_norms_temp];
end
h = h(1,1,:);
res_norms = res_norms/sqrt(inner_product_joint(rhs_samplef,rhs_samplef));
