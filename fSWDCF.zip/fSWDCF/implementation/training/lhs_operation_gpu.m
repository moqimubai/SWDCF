function h_out = lhs_operation_gpu(h, samplesf, sample_weights,pad_sz, pad, filter_reg, w)

hw = cellfun(@(h, w) bsxfun(@times, h, w), h, w, 'uniformoutput', false);
% This is the left-hand-side operation in Conjugate Gradient
hf = cellfun(@(h, pad_sz, pad) h2hf_gpu(h, pad_sz, pad), hw, pad_sz, pad, 'uniformoutput',false);

% Get sizes
num_features = length(hf);
filter_sz = zeros(num_features,2);
for k = 1:num_features
    filter_sz(k,:) = [size(hf{k},1), size(hf{k},2)];
end
[~, k1] = max(filter_sz(:,1));  % Index for the feature block with the largest spatial size
block_inds = 1:num_features;
block_inds(k1) = [];

% Compute the operation corresponding to the data term in the optimization
% (blockwise matrix multiplications)
%implements: A' diag(sample_weights) A f

% sum over all features and feature blocks
sh = sum(bsxfun(@times, samplesf{k1}, hf{k1}), 3);    % assumes the feature with the highest resolution is first
for k = block_inds
    sh(1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end,1,:) = ...
        sh(1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end,1,:) + sum(bsxfun(@times, samplesf{k}, hf{k}), 3);
end

% weight all the samples and take conjugate
sh = conj(bsxfun(@times,sample_weights,sh));

% multiply with the transpose
hf_out = cell(1,1,num_features);
hf_out{k1} = conj(sum(bsxfun(@times, sh, samplesf{k1}), 4));
for k = block_inds
    hf_out{k} = conj(sum(bsxfun(@times, sh(1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end,1,:), samplesf{k}), 4));
end
h_out = cellfun(@(xf, pad_sz, pad) hf2h_gpu(xf, pad_sz, pad), hf_out, pad_sz, pad, 'uniformoutput', false);
h_out = cellfun(@(h, w) bsxfun(@times, h, w), h_out, w, 'uniformoutput', false);
h_out = cellfun(@(h_out, h) h_out+filter_reg * h, h_out, h, 'uniformoutput', false);

end