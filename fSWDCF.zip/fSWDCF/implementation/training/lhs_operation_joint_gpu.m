function h_out = lhs_operation_joint_gpu(h, samplesf, reg_filter, init_samplef, XH, init_hf, init_h_H,proj_reg,filter_reg,pad_sz,pad)

% This is the left-hand-side operation in Conjugate Gradient

hf_out = cell(size(h));
hf = cellfun(@(h,pad_sz,pad) h2hf(h,pad_sz, pad), h(1,1,:),pad_sz,pad, 'uniformoutput',false);
% Extract projection matrix and filter separately
P = cellfun(@real, h(2,1,:), 'uniformoutput',false);

% Get sizes
num_features = length(hf);
filter_sz = zeros(num_features,2);
for k = 1:num_features
    filter_sz(k,:) = [size(hf{k},1), size(hf{k},2)];
end
[~, k1] = max(filter_sz(:,1));  % Index for the feature block with the largest spatial size
block_inds = 1:num_features;
block_inds(k1) = [];
output_sz = [size(hf{k1},1), 2*size(hf{k1},2)-1];

% Compute the operation corresponding to the data term in the optimization
% (blockwise matrix multiplications)
%implements: A' diag(sample_weights) A f

% sum over all features and feature blocks
sh = sum(bsxfun(@times, samplesf{k1}, hf{k1}), 3);    % assumes the feature with the highest resolution is first
pad_sz = cell(1,1,num_features);
pad_sz{k1} = [0,0];
for k = block_inds
    pad_sz{k} = (output_sz - [size(hf{k},1), 2*size(hf{k},2)-1]) / 2;
    
    sh(1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end,1,:) = ...
        sh(1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end,1,:) + sum(bsxfun(@times, samplesf{k}, hf{k}), 3);
end

% weight all the samples and take conjugate
% sh = bsxfun(@times,sample_weights,sh);
sh = conj(sh);

% multiply with the transpose
hf_out1 = cell(1,1,num_features);
hf_out1{k1} = conj(sum(bsxfun(@times, sh, samplesf{k1}), 4));
for k = block_inds
    hf_out1{k} = conj(sum(bsxfun(@times, sh(1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end,1,1,:), samplesf{k}), 4));
end

% B * P
BP_cell = cell(1,1,num_features);
for k = 1:num_features
    BP_cell{k} = sum(bsxfun(@times, reshape(reshape(init_samplef{k}, [], size(init_samplef{k},3)) * P{k}, size(init_samplef{k},1), size(init_samplef{k},2), []), init_hf{k}), 3);
end

BP = BP_cell{k1};
for k = block_inds
    BP(1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end) = ...
        BP(1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end) + BP_cell{k};
end

% multiply with the transpose: A^H * BP
hf_out{1,1,k1} = hf_out1{k1} +  bsxfun(@times, BP, conj(samplesf{k1}));

% B^H * BP
XfBP = cell(1,1,num_features);
XfBP{k1} = bsxfun(@times, conj(init_samplef{k1}), BP);

% Compute proj matrix part: B^H * A_m * f
Xfsh = cell(1,1,num_features);
Xfsh{k1} = bsxfun(@times, conj(init_samplef{k1}), sh);

for k = block_inds
    % multiply with the transpose: A^H * BP
    hf_out{1,1,k} = hf_out1{k} +  bsxfun(@times, BP(1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end), conj(samplesf{k}));
    
    % B^H * BP
    XfBP{k} = bsxfun(@times, conj(init_samplef{k}), BP(1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end));
    
    % Compute proj matrix part: B^H * A_m * f
    Xfsh{k} = bsxfun(@times, conj(init_samplef{k}), sh(1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end));
end

h_out(1,1,:) = cellfun(@(m, pad_sz, pad) hf2h(m, pad_sz, pad), hf_out(1,1,:), pad_sz, pad,  'uniformoutput', false);
XBP = cellfun(@(m, pad_sz, pad) hf2h(m, pad_sz, pad), XfBP, pad_sz, pad, 'uniformoutput', false);
XBP_H = cellfun(@(m) reshape(m, [], size(m,3))', XBP, 'uniformoutput', false);

Xsh = cellfun(@(m, pad_sz, pad) hf2h(m, pad_sz, pad), Xfsh, pad_sz, pad, 'uniformoutput', false);
Xsh_H = cellfun(@(m) reshape(m, [], size(m,3))', Xsh, 'uniformoutput', false);

for k = 1:num_features
    h_out{1,1,k} = h_out{1,1,k} + filter_reg * h{1,1,k};
    hf_out2 = real(XBP_H{k} * init_h_H{k}) + proj_reg * P{k};
    h_out{2,1,k} = hf_out2 + real(Xsh_H{k} * init_h_H{k});
end
