function d = make_diag_precond_p(xlf,h,P,pad_sz, pad)

      hf = h2hf(h,pad_sz,pad)/size(xlf,1)/(2*size(xlf,2)-1);
     for i = 1:size(P,1)
         for j = 1:size(P,2)
             xf = xlf(:,:,i).*hf(:,:,j);
             d(i,j) = 2*sum(sum(conj(xf).*xf));
         end
     end
end