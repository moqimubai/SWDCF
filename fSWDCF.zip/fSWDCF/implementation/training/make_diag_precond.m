function d = make_diag_precond(xf, pad_sz, pad)

% This is the preconditioner operation in Conjugate Gradient
    Xf = gpuArray(zeros(size(xf,1)+2*pad_sz(1),2*size(xf,2)-1+2*pad_sz(2),size(xf,3)));
    Xf(1+pad_sz(1):end-pad_sz(1), 1+pad_sz(2):end-pad_sz(2),:) = full_fourier_coeff(xf);
    X=cifft2(Xf);
    D=sum(sum(conj(X).*X));
    d= gpuArray(ones(size(X,1)-2*pad(1), size(X,2)-2*pad(2), size(X,3)));
    for i = 1:size(xf,3)
         d(:,:,i) = D(i)*d(:,:,i);
    end
    
%     Xf = zeros(size(xf,1)+2*pad_sz(1),2*size(xf,2)-1+2*pad_sz(2),size(xf,3));
%     Xf(1+pad_sz(1):end-pad_sz(1), 1+pad_sz(2):end-pad_sz(2),:) = full_fourier_coeff(xf);
%     X=cifft2(Xf);
%     D=sum(sum(conj(X).*X));
%     d= ones(size(X,1)-2*pad(1), size(X,2)-2*pad(2), size(X,3));
%     for i = 1:size(xf,3)
%          d(:,:,i) = D(i)*d(:,:,i);
%     end
end