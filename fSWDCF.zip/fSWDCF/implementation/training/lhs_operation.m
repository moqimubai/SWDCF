function h_out = lhs_operation(h, samplesf, sample_weights,pad_sz, pad, filter_reg, w)

% This is the left-hand-side operation in Conjugate Gradient
hw = cellfun(@(h, w) bsxfun(@times, h, w), h, w, 'uniformoutput', false);
hf = cellfun(@(h, pad_sz, pad) h2hf(h, pad_sz, pad), hw, pad_sz, pad, 'uniformoutput',false);
% Get sizes
num_features = length(hf);
filter_sz = zeros(num_features,2);
for k = 1:num_features
    filter_sz(k,:) = [size(hf{k},1), size(hf{k},2)];
end
[~, k1] = max(filter_sz(:,1));  % Index for the feature block with the largest spatial size
block_inds = 1:num_features;
block_inds(k1) = [];

% Compute the operation corresponding to the data term in the optimization
% (blockwise matrix multiplications)
%implements: A' diag(sample_weights) A f
% sum over all features and feature blocks
sh = mtimesx(samplesf{k1}, permute(hf{k1}, [3 4 1 2]), 'speed');    % assumes the feature with the highest resolution is first
for k = block_inds
    sh(:,1,1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end) = ...
        sh(:,1,1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end) + mtimesx(samplesf{k}, permute(hf{k}, [3 4 1 2]), 'speed');
end

% weight all the samples
sh = bsxfun(@times,sample_weights,sh);

% multiply with the transpose
hf_out = cell(1,1,num_features);
hf_out{k1} = permute(conj(mtimesx(sh, 'C', samplesf{k1}, 'speed')), [3 4 2 1]);
for k = block_inds
    hf_out{k} = permute(conj(mtimesx(sh(:,1,1+pad_sz{k}(1):end-pad_sz{k}(1), 1+pad_sz{k}(2):end), 'C', samplesf{k}, 'speed')), [3 4 2 1]);
end

% compute the operation corresponding to the regularization term (convolve
% each feature dimension with the DFT of w, and the tramsposed operation)
% add the regularization part
% hf_conv = cell(1,1,num_features);
h_out = cellfun(@(xf, pad_sz, pad) hf2h(xf, pad_sz, pad), hf_out, pad_sz, pad, 'uniformoutput', false);
h_out = cellfun(@(h, w) bsxfun(@times, h, w), h_out, w, 'uniformoutput', false);
h_out = cellfun(@(h_out, h) h_out+filter_reg * h, h_out, h, 'uniformoutput', false);

end