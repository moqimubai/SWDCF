function hf = h2hf(h, pad_sz, pad)
    H = gpuArray(zeros(size(h,1)+2*pad(1), size(h,2)+2*pad(2), size(h,3)));
    H(1+pad(1):end-pad(1),1+pad(2):end-pad(2),:) = h;
    Hf = cfft2(H);
    hf = compact_fourier_coeff(Hf(1+pad_sz(1):end-pad_sz(1),1+pad_sz(2):end-pad_sz(2),:));
end