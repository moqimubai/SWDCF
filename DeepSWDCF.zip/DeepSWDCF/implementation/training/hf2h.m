function d = hf2h(xf, pad_sz, pad)
    Xf = zeros(size(xf,1)+2*pad_sz(1),2*size(xf,2)-1+2*pad_sz(2),size(xf,3));
    Xf(1+pad_sz(1):end-pad_sz(1), 1+pad_sz(2):end-pad_sz(2),:) = full_fourier_coeff(xf);
    X=cifft2(Xf);
    d= X(1+pad(1):end-pad(1),1+pad(2):end-pad(2), :);
end