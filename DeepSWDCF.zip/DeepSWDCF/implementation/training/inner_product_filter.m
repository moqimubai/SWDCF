function ip = inner_product_filter(xf, yf)

% Computes the inner product between two filters.

ip = 0;
for k = 1:length(xf)
    ip = ip + gather(xf{k}(:)' * yf{k}(:));
end
ip = real(ip);
